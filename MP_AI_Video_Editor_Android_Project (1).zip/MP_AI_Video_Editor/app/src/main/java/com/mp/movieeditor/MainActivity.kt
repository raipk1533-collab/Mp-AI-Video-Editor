package com.mp.movieeditor

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {
    private var selectedVideo: Uri? = null
    private lateinit var status: TextView
    private lateinit var chooseButton: Button
    private lateinit var exportButton: Button

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            selectedVideo = uri
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            status.text = "भिडियो छानियो। अब 16:9 मा Export गर्न सक्नुहुन्छ।"
            exportButton.isEnabled = true
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            setBackgroundColor(0xFF10101A.toInt())
        }

        val title = TextView(this).apply {
            text = "MP AI Video Editor"
            textSize = 26f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 8, 0, 8)
        }
        val subtitle = TextView(this).apply {
            text = "9:16  →  16:9"
            textSize = 22f
            setTextColor(0xFF00C2A8.toInt())
            setPadding(0, 4, 0, 24)
        }
        val explanation = TextView(this).apply {
            text = "Portrait भिडियो छान्नुहोस्। एपले बीचमा मूल भिडियो राखेर दायाँ-बायाँ मिल्दो blurred background बनाउनेछ।"
            textSize = 15f
            setTextColor(0xFFE6E6F0.toInt())
            setPadding(0, 0, 0, 24)
        }
        chooseButton = Button(this).apply {
            text = "भिडियो छान्नुहोस्"
            setOnClickListener { picker.launch(arrayOf("video/*")) }
        }
        exportButton = Button(this).apply {
            text = "16:9 भिडियो Export गर्नुहोस्"
            isEnabled = false
            setOnClickListener { exportVideo() }
        }
        status = TextView(this).apply {
            text = "अहिलेसम्म भिडियो छानिएको छैन।"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 22, 0, 0)
        }
        val note = TextView(this).apply {
            text = "\nनोट: यो पहिलो MVP संस्करण हो। अहिले background विस्तार blur-based छ, वास्तविक generative AI background होइन। वास्तविक AI विस्तारका लागि छुट्टै AI सेवा/API जोड्नुपर्छ।"
            textSize = 12f
            setTextColor(0xFFB8B8C8.toInt())
        }

        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(explanation)
        layout.addView(chooseButton)
        layout.addView(exportButton)
        layout.addView(status)
        layout.addView(note)
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun exportVideo() {
        val uri = selectedVideo ?: return
        chooseButton.isEnabled = false
        exportButton.isEnabled = false
        status.text = "भिडियो तयार हुँदैछ… कृपया पर्खनुहोस्।"

        Thread {
            try {
                val input = File(cacheDir, "input_video.mp4")
                contentResolver.openInputStream(uri).use { stream ->
                    requireNotNull(stream) { "भिडियो खोल्न सकिएन" }
                    FileOutputStream(input).use { out -> stream.copyTo(out) }
                }
                val movies = getExternalFilesDir("Movies") ?: filesDir
                val output = File(movies, "MP_AI_${System.currentTimeMillis()}.mp4")
                val inPath = input.absolutePath.replace("'", "'\\''")
                val outPath = output.absolutePath.replace("'", "'\\''")
                val command = "-y -i '$inPath' -filter_complex " +
                    "\"[0:v]split=2[bg][fg];" +
                    "[bg]scale=1920:1080:force_original_aspect_ratio=increase,crop=1920:1080,boxblur=28:10[back];" +
                    "[fg]scale=1920:1080:force_original_aspect_ratio=decrease[front];" +
                    "[back][front]overlay=(W-w)/2:(H-h)/2,format=yuv420p[v]\" " +
                    "-map \"[v]\" -map 0:a? -c:v libx264 -preset veryfast -crf 22 -c:a aac -b:a 192k -movflags +faststart '$outPath'"

                val session = FFmpegKit.execute(command)
                if (ReturnCode.isSuccess(session.returnCode)) {
                    runOnUiThread {
                        status.text = "Export पूरा भयो!\nफाइल: ${output.name}\nApp Movies फोल्डरमा सुरक्षित छ।"
                        chooseButton.isEnabled = true
                        exportButton.isEnabled = true
                    }
                } else {
                    val detail = session.failStackTrace ?: session.allLogsAsString.takeLast(500)
                    runOnUiThread {
                        status.text = "Export असफल भयो।\n$detail"
                        chooseButton.isEnabled = true
                        exportButton.isEnabled = true
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "त्रुटि: ${e.message}"
                    chooseButton.isEnabled = true
                    exportButton.isEnabled = true
                }
            }
        }.start()
    }
}
