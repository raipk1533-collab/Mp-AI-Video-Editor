# MP AI Video Editor — Android starter project

यो Android Studio का लागि तयार गरिएको starter/MVP project हो।

## अहिले के काम गर्छ?
- Android बाट भिडियो छान्ने
- 9:16 जस्ता portrait भिडियोको 16:9 output बनाउने
- मूल भिडियो बीचमा राख्ने
- दायाँ-बायाँ उही भिडियोबाट blurred background बनाउने
- MP4 मा export गर्ने

## अझै के छैन?
**यो वास्तविक generative AI outpainting होइन।** यसले दृश्यको नयाँ भाग AI बाट कल्पना गरेर बनाउँदैन; blur background बनाउँछ। वास्तविक AI background expansion का लागि छुट्टै AI video/image API वा आफ्नै backend चाहिन्छ। API key एपभित्र खुला रूपमा नराख्नुहोस्; backend मार्फत सुरक्षित रूपमा जोड्नुहोस्।

## APK कसरी बनाउने?
1. Android Studio खोल्नुहोस्।
2. `MP_AI_Video_Editor` folder लाई Open गर्नुहोस्।
3. Gradle sync हुन दिनुहोस्।
4. Android SDK 35 र JDK 17 उपलब्ध हुनुपर्छ।
5. `Build > Build Bundle(s) / APK(s) > Build APK(s)` छान्नुहोस्।

APK सामान्यतया `app/build/outputs/apk/debug/app-debug.apk` मा आउँछ।

## महत्त्वपूर्ण build note
FFmpegKit परियोजना discontinued भएकोले यस starter मा राखिएको legacy dependency Maven बाट उपलब्ध नहुन सक्छ वा production प्रयोगका लागि उपयुक्त नहुन सक्छ। Build गर्दा dependency resolution error आएमा maintained FFmpeg Android distribution/provider ले बदल्नुपर्छ। यो project यहाँ compile/test गरिएको छैन; त्यसैले APK तयार/परीक्षण भएको दाबी गरिएको छैन।
